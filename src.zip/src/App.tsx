import { useState } from 'react';
import './App.css';

interface AppProps {
  name: string;
}

function App({ name }: AppProps) {
  return (
    <div>
      <h1>Hello {name}</h1>
    </div>
  );
}

export default App;
